#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
@interface API : NSObject
NS_ASSUME_NONNULL_BEGIN

- (void)paid:(void (^)(void))execute;
+ (void)setToken:(NSString*)settoken;
- (void)login;
- (NSString*)g_u_d;
- (NSString *)g_d_n;
- (NSString *)g_m_d;
- (NSString *)g_v_i;
@end
NS_ASSUME_NONNULL_END

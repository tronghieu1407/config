#import "meo.h"
#import "Main.h"
#include "LoadView/Includes.h"
#import "Security/oxorany/oxorany_include.h"
#import "Security/oxorany/oxorany.h"
#include <Foundation/Foundation.h>
#include <libgen.h>
#include <mach-o/dyld.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach/vm_page_size.h>
#include <unistd.h>
#include <array>
#include <deque>
#include <map>
#include <vector>
#import "imgui/Il2cpp.h"
#import "LoadView/Icon.h"
#import "imgui/stb_image.h"
#include "hook/hook.h"
#import "imgui/CaptainHook.h"
#import "imgui/imgui_additional.h"
#include <CoreFoundation/CoreFoundation.h>
#import "mahoa.h"
#import "cac.h"
#import "Theme.h"
//#import "igg.mm"
#include "hack/Vector3.h"
#include "hack/Vector2.h"
#include "hack/Quaternion.h"
#include "hack/Monostring.h"
#include "Esp.h"
#import "JRMemory.framework/Headers/MemScan.h"
#import "LoadView/CTCheckbox.h"
#define kWidth [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

CTCheckbox *checkbox1;
CTCheckbox *checkbox2;
UIWindow *mainWindow;
UIButton *menuView;
UIButton *openButton;
UIButton *closeButton;
UIButton *clean;
UIView *menu;
UIButton *movingView;

using namespace IL2Cpp;
@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
- (void)ghost;
- (void)removeGhost; 
- (void)switchIsChanged:(UISwitch *)SW1;

@end
@implementation ImGuiDrawView
static float tabContentOffsetY[5] = {20.0f, 20.0f, 20.0f, 20.0f, 20.0f}; 
static float tabContentAlpha[5] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f}; 
static int selectedTab = 1;
static int lastSelectedTab = -1; 

const float TAB_CONTENT_ANIMATION_SPEED = 5.7f;
const float BUTTON_WIDTH = 82.0f;
const float BUTTON_HEIGHT = 29.0f;

void AnimateTabContent(int index, bool isActive) {
    if (isActive) {
        if (tabContentOffsetY[index] > 0.0f) {
            tabContentOffsetY[index] -= ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED * 20.0f;
            if (tabContentOffsetY[index] < 0.0f) {
                tabContentOffsetY[index] = 0.0f;
            }
        }
        if (tabContentAlpha[index] < 1.0f) {
            tabContentAlpha[index] += ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED;
            if (tabContentAlpha[index] > 1.0f) {
                tabContentAlpha[index] = 1.0f;
            }
        }
    } else {
        if (tabContentOffsetY[index] < 20.0f) {
            tabContentOffsetY[index] += ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED * 20.0f;
            if (tabContentOffsetY[index] > 20.0f) {
                tabContentOffsetY[index] = 20.0f;
            }
        }
        if (tabContentAlpha[index] > 0.0f) {
            tabContentAlpha[index] -= ImGui::GetIO().DeltaTime * TAB_CONTENT_ANIMATION_SPEED;
            if (tabContentAlpha[index] < 0.0f) {
                tabContentAlpha[index] = 0.0f;
            }
        }
    }
}
ImFont* _espFont;
ImFont *_iconFont;

BOOL hasGhostBeenDrawn = NO;
static std::string selectedStyle = "Dark";

bool napdannhanh = false;
float Napdannhanh(void *instance) {
     if (napdannhanh) {
         return 100.0;//nạp đạn nhanh
     }
}

float camxa = 60; 
int Camxa(void *instance) {
    if (camxa > 0.0) {
        return 150.0; 
    } else {
        return 60.0;
    }
}



bool norecoi = false;
int Norecoi(void *instance) {
     if (norecoi) {
         return 99;
     }else{
    return 1;
    }
}

bool rss = false;
bool Guest(void* _this){
    if (rss){
      return true; 
    }
}
bool sen = false;
bool cc = false;
bool BlockHost = false;
bool aim180 = false;
bool tawm = false;
bool Locktam = false;
bool aimawm = false;
bool aimscope = false;
bool hscu = false;
bool antenatay = false;
bool chao = false;
bool votay = false;
bool khieukhich = false;
bool dab = false;
bool cuoi = false;
bool doa = false;
bool httc = false;
bool cttc = false;
bool m4a1 = false;
bool ump = false;
bool igg = false;
bool dame = false;
bool ngnghieng = false;
bool codai = false;



 -(void)ghost {  
    mainWindow = [[UIApplication sharedApplication] keyWindow];  

    if (!menuView) {  
        // Tạo menuView với nền tròn màu đen nhạt  
        menuView = [UIButton buttonWithType:UIButtonTypeCustom]; // Thay đổi ở đây  
// Tạo hình tròn
        menuView.frame = CGRectMake(305, 265, 70, 70);  
        menuView.layer.cornerRadius = menuView.bounds.size.width / 2; // Hình tròn  
        menuView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6]; // Nền đen nhạt  
        menuView.alpha = 1.0f;  

        // Đảm bảo chỉ thêm vào cửa sổ chính một lần  
        [mainWindow addSubview:menuView];  

        // Thêm sự kiện kéo nút sử dụng UIPanGestureRecognizer  
        UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];  
        [menuView addGestureRecognizer:panGesture];  

        // Thêm nhãn cho trạng thái Aimbot  
        UILabel *aimLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 25, 70, 20)]; // Đặt đúng vị trí  
        aimLabel.font = [UIFont fontWithName:@"CourierNewPS-BoldMT" size:16];  
        aimLabel.textAlignment = NSTextAlignmentCenter; // Canh giữa  
        aimLabel.backgroundColor = [UIColor clearColor]; // Không có nền  
        aimLabel.tag = 100; // Gán thẻ để truy xuất sau  

        // Thêm nhãn vào menuView  
        [menuView addSubview:aimLabel];  

        // Đặt văn bản cho nhãn  
        aimLabel.text = @"ON";   
        aimLabel.textColor = [UIColor redColor]; // Màu chữ bắt đầu là đỏ (tắt)  

        // Tạo nút để bật/tắt Aimbot  
        UIButton *aimButton = [UIButton buttonWithType:UIButtonTypeCustom];  
        aimButton.frame = CGRectMake(0, 0, 70, 70); // Kích thước giống như menuView  
        aimButton.layer.cornerRadius = aimButton.bounds.size.width / 2; // Tạo hình tròn  
        
        aimButton.backgroundColor = [UIColor clearColor]; // Nền trong suốt  
        [aimButton addTarget:self action:@selector(switchIsChanged:) forControlEvents:UIControlEventTouchUpInside];  

        // Thêm nút vào menuView  
        [menuView addSubview:aimButton];  

        hasGhostBeenDrawn = YES; // Đánh dấu menu đã được vẽ  
    }  
}  

// Phương thức gọi khi Aimbot bị bật/tắt  
- (void)switchIsChanged:(UIButton *)button {  
    dispatch_async(dispatch_get_main_queue(), ^{  
        UILabel *aimLabel = (UILabel *)[[button superview] viewWithTag:100]; // Tìm nhãn  

        if ([aimLabel.textColor isEqual:[UIColor redColor]]) {  
            // Bật Aimbot  
            Aimbot = true;  
            aimLabel.textColor = [UIColor greenColor]; // Đổi màu chữ thành xanh  
        } else {  
            // Tắt Aimbot  
            Aimbot = false;  
            aimLabel.textColor = [UIColor redColor]; // Đổi màu chữ thành đỏ  
        }  
    });  
}  

// Phương thức gọi khi xóa menu  

- (void)removeGhost {  
    if (menuView) {  
        [menuView removeFromSuperview];  
        menuView = nil;  
        hasGhostBeenDrawn = NO;  
    }  
}  

// Phương thức xử lý kéo  
- (void)handlePan:(UIPanGestureRecognizer *)gesture {  
    CGPoint translation = [gesture translationInView:mainWindow];  
    CGPoint newCenter = CGPointMake(gesture.view.center.x + translation.x, gesture.view.center.y + translation.y);  
    gesture.view.center = newCenter; // Cập nhật vị trí của nút  
    [gesture setTranslation:CGPointZero inView:mainWindow]; // Đặt lại translation về 0  
} 


- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];

    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) abort();

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowPadding = ImVec2(10, 10);
    style.WindowRounding = 5.0f;
    style.FramePadding = ImVec2(5, 5);
    style.FrameRounding = 4.0f;
    style.ItemSpacing = ImVec2(5, 3);//12,8
    style.ItemInnerSpacing = ImVec2(8, 6);
    style.IndentSpacing = 12.0f;//25.0f
    style.ScrollbarSize = 15.0f;
    style.ScrollbarRounding = 9.0f;
    style.GrabMinSize = 5.0f;
    style.GrabRounding = 3.0f;
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 1.0f;
    style.PopupBorderSize = 1.0f;
    style.Alpha = 1.0f;

   


    ImFontConfig config;
    ImFontConfig icons_config;
    config.FontDataOwnedByAtlas = false;
    icons_config.MergeMode = true;
    icons_config.PixelSnapH = true;
    icons_config.OversampleH = 2;
    icons_config.OversampleV = 2;

    static const ImWchar icons_ranges[] = { 0xf000, 0xf3ff, 0 };

    NSString *fontPath = nssoxorany("/System/Library/Fonts/Core/AvenirNext.ttc");

    _espFont = io.Fonts->AddFontFromFileTTF(fontPath.UTF8String, 30.f, &config, io.Fonts->GetGlyphRangesVietnamese());

    _iconFont = io.Fonts->AddFontFromMemoryCompressedTTF(font_awesome_data, font_awesome_size, 19.0f, &icons_config, icons_ranges);

    _iconFont->FontSize = 5;
    io.FontGlobalScale = 0.5f;

    ImGui_ImplMetal_Init(_device);

    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

+ (BOOL)isMenuShowing {
    return MenDeal;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}



- (void)loadView
{
    CGFloat w = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width;
    CGFloat h = [UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height;
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    if (!self.mtkView.device) {
        return;
    }
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;

    void* address[] = {  
         
(void*)getRealOffset(ENCRYPTOFFSET("0x10529A408")), //Update

(void*)getRealOffset(ENCRYPTOFFSET("0x1052620FC")),//ondestroy
              (void*)getRealOffset(ENCRYPTOFFSET("0x1040D6610")),//Napdannhanh
         (void*)getRealOffset(ENCRYPTOFFSET("0x1022D3F80")),//Haisung
        (void*)getRealOffset(ENCRYPTOFFSET("0x103E526F0")),//Camxa
(void*)getRealOffset(ENCRYPTOFFSET("0x1051D1F94")),
    };
    void* function[] = {
        
        (void*)Update,
        (void*)OnDestroy,
        (void*)Napdannhanh,
        (void*)Guest,
        (void*)Camxa,
        (void*)Norecoi,
    };
    hook(address, function, 6);
_GetHeadPositions = (void*(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BECB8"));
_newHipMods = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BEE08"));
_GetLeftAnkleTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF13C"));
_GetRightAnkleTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF1E0"));
_GetLeftToeTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF284"));
_GetRightToeTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052BF328"));
_getLeftHandTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C0E8"));
_getRightHandTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C194"));
_getLeftForeArmTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C238"));
_getRightForeArmTF = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x10525C2DC"));

    Local = (bool (*)(void *))getRealOffset(ENCRYPTOFFSET("0x105258C80"));                              
    Team = (bool (*)(void *))getRealOffset(ENCRYPTOFFSET("0x10526D118"));                               
    get_CurHP = (int (*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052A8A30"));                           
    get_MaxHP = (int(*)(void *))getRealOffset(ENCRYPTOFFSET("0x1052A8AD8"));                            
    get_position = (Vector3(*)(void *))getRealOffset(ENCRYPTOFFSET("0x105F3D46C"));                     
    WorldToViewpoint = (Vector3(*)(void *, Vector3, int))getRealOffset(ENCRYPTOFFSET("0x105EF6394"));  
    get_main = (void *(*)())getRealOffset(ENCRYPTOFFSET("0x105EF6D08"));                                
    get_transform = (void *(*)(void *))getRealOffset(ENCRYPTOFFSET("0x105EF8D78"));                    

}
static bool MenDeal = false;
static bool StreamerMode = false;

- (void)drawInMTKView:(MTKView*)view
{

    hideRecordTextfield.secureTextEntry = StreamerMode;

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.nativeScale ?: UIScreen.mainScreen.nativeScale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 60);
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
        
        if (MenDeal == true) 
        {
            [self.view setUserInteractionEnabled:YES];
            [self.view.superview setUserInteractionEnabled:YES];
            [menuTouchView setUserInteractionEnabled:YES];
        } 
        else if (MenDeal == false) 
        {
           
            [self.view setUserInteractionEnabled:NO];
            [self.view.superview setUserInteractionEnabled:NO];
            [menuTouchView setUserInteractionEnabled:NO];

        }

        MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
        if (renderPassDescriptor != nil)
        {
            id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
            [renderEncoder pushDebugGroup:nssoxorany("ImGui Jane")];

            ImGui_ImplMetal_NewFrame(renderPassDescriptor);
            ImGui::NewFrame();

            CGFloat width = 520;
            CGFloat height = 340;
            ImGui::SetNextWindowPos(ImVec2((kWidth - width) / 2, (kHeight - height) / 2), ImGuiCond_FirstUseEver);
            ImGui::SetNextWindowSize(ImVec2(width, height), ImGuiCond_FirstUseEver);

            
if (MenDeal) {
            ImGui::Begin(ICON_FA_USER_CIRCLE" Freefire - Hạo Nguyên | @haonguyenolios", &MenDeal);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);

            // Tab Buttons
            ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 0 ? ImVec4(0.12f, 0.15f, 0.18f, 1.0f) : ImVec4(0.08f, 0.08f, 0.08f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.38f, 0.38f, 0.38f, 1.00f));
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.20f, 0.25f, 0.30f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 0 ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.75f, 0.75f, 0.75f, 1.0f));

             if 
(ImGui::Button(ICON_FA_ID_CARD " ADMIN", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) {
                selectedTab = 0;
          }
            ImGui::PopStyleColor(4);

            ImGui::SameLine();

            ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 1 ? ImVec4(0.12f, 0.15f, 0.18f, 1.0f) : ImVec4(0.08f, 0.08f, 0.08f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.38f, 0.38f, 0.38f, 1.00f));
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.20f, 0.25f, 0.30f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 1 ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.75f, 0.75f, 0.75f, 1.0f));

            if (ImGui::Button(ICON_FA_EYE " ESP", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) {
                selectedTab = 1;
            }
            ImGui::PopStyleColor(4);

            ImGui::SameLine();

            ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 2 ? ImVec4(0.12f, 0.15f, 0.18f, 1.0f) : ImVec4(0.08f, 0.08f, 0.08f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.38f, 0.38f, 0.38f, 1.00f));
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.20f, 0.25f, 0.30f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 2 ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.75f, 0.75f, 0.75f, 1.0f));

            
         if (ImGui::Button(ICON_FA_GAMEPAD "  FUNCTION", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) 
{
                
                selectedTab = 2;
            }
            ImGui::PopStyleColor(4);

            ImGui::SameLine();

ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 3 ? ImVec4(0.12f, 0.15f, 0.18f, 1.0f) : ImVec4(0.08f, 0.08f, 0.08f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.38f, 0.38f, 0.38f, 1.00f));
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.20f, 0.25f, 0.30f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 3 ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.75f, 0.75f, 0.75f, 1.0f));

    if 
(ImGui::Button(ICON_FA_CODE " MOD", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) 
   {
                
                selectedTab = 3;
            }
            ImGui::PopStyleColor(4);

            ImGui::SameLine();

ImGui::PushStyleColor(ImGuiCol_Button, selectedTab == 3 ? ImVec4(0.12f, 0.15f, 0.18f, 1.0f) : ImVec4(0.08f, 0.08f, 0.08f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.38f, 0.38f, 0.38f, 1.00f));
ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.20f, 0.25f, 0.30f, 1.0f));
ImGui::PushStyleColor(ImGuiCol_Text, selectedTab == 3 ? ImVec4(1.0f, 1.0f, 1.0f, 1.0f) : ImVec4(0.75f, 0.75f, 0.75f, 1.0f));

    if 
(ImGui::Button(ICON_FA_CUBES " CONTROL", ImVec2(BUTTON_WIDTH, BUTTON_HEIGHT))) 
   {
                
                selectedTab = 4;
            }
           //notii

            
            if (lastSelectedTab != selectedTab) {
               
                for (int i = 0; i < 4; ++i) { 
                    tabContentOffsetY[i] = 20.0f;
                    tabContentAlpha[i] = 0.0f;
                }
                lastSelectedTab = selectedTab;
            }
            AnimateTabContent(selectedTab, true);

            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(12, 8 + tabContentOffsetY[selectedTab]));
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, tabContentAlpha[selectedTab]);
            
            
            if (selectedTab == 0) {

             ImGui::Separator();


             ImGui::TextColored(ImColor(255, 255, 255), "   Contact to Admin");

            if (ImGui::Button(ENCRYPT("Telegram"))) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://t.me/haonguyenolios"]];
            }

            if (ImGui::Button(ENCRYPT("Admin's Zalo"))) {
               [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://zalo.me/0946544624"]];
            }
           
            if 
(ImGui::Button(ENCRYPT("Zalo Community"))) {
               [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://zalo.me/g/lirucc084"]];
            }

            if 
(ImGui::Button(ENCRYPT("Discord Community"))) {
               [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://discord.gg/JYpTX5zp"]];
            }
            ImGui::TextColored(ImColor(0, 255, 255), "Project's Infinity Team");

ImGui::TextColored(ImColor(242, 70, 44), "Contact to buy key");

                
     
 

                ImGui::Spacing();
            }  else
 if (selectedTab == 1) {
                ImGui::Spacing();
                ImGui::Separator();
                ImGui::TextColored(ImColor(0, 255, 0), "Main Function");
                ImGui::Checkbox(ENCRYPT("ESP"), &ESPEnable);

ImGui::SliderFloat(ENCRYPT("ESP Distance"), &sliderDistanceValue, 0.0f, 999.0f);

ImGui::Checkbox(ENCRYPT("Line"), &ESPLine);
ImGui::SameLine(100); 
ImGui::Checkbox(ENCRYPT("Box"), &ESPBox);
ImGui::SameLine(200); 
ImGui::Checkbox(ENCRYPT("Alert"), &ESPArrow);

                ImGui::Checkbox(ENCRYPT("Bone"), &bone);
ImGui::SameLine(100); 
ImGui::Checkbox(ENCRYPT("Name"), &ESPName); 
ImGui::SameLine(200); 
ImGui::Checkbox(ENCRYPT("Health"), &ESPHealth); 

ImGui::Checkbox(ENCRYPT("Number"), &ESPCount);  ImGui::SameLine(100);                
ImGui::Checkbox(ENCRYPT("Distance"), &ESPDistance);

                
            } if (selectedTab == 2) {
                ImGui::Spacing();
                ImGui::Separator();

ImGui::BeginGroupPanel("AIMBOT", ImVec2(470, 0));
       
            
                ImGui::Checkbox(ENCRYPT("AIMBOT"), &sen);
                
ImGui::Checkbox(ENCRYPT("FOV"), &Fov);ImGui::SameLine(); 

ImGui::SliderFloat(ENCRYPT("FOV Size"), &circle_size, 0.0f, 999.0f);
DrawAimbotTab();
 ImGui::EndGroupPanel();

ImGui::BeginGroupPanel("IGG (AntiBan)", ImVec2(470, 0));
ImGui::TextColored(ImColor(255, 0, 0), "IGG Function only turn on once and cant be turned off");
ImGui::Checkbox("Aim 360", &aim180); 

ImGui::Checkbox("Aimlock", &Locktam); 

ImGui::Checkbox("Buff Dame", &dame);

ImGui::Checkbox("Aim Scope", &aimscope); 

//ImGui::Checkbox("Awm", &tawm); 

ImGui::Checkbox("Headshot", &hscu); 

//ImGui::Checkbox("Aim For Awm", &aimawm); 

//ImGui::Checkbox("Antena", &antenatay); 

ImGui::Checkbox("Speed", &igg); 
//ImGui::TextColored(ImColor(255, 56, 56), "if use speed u can got banned because its risk function ");


ImGui::TextColored(ImColor(255, 255, 0), "");

//vỗ tay ak khiêu khích ump pc dab an than chi thuat cười iu hay 

 ImGui::EndGroupPanel();

} if (selectedTab == 3) {
              ImGui::Separator();

ImGui::TextColored(ImColor(255, 255, 255), " IGG Mod, Another players in freefire can see:3");

ImGui::TextColored(ImColor(28, 198, 255), "New Action");

ImGui::Checkbox("Rasengan: Chào", &chao); 

ImGui::Checkbox("Ẩn Thân Chi Thuật: Khiêu Khích", &khieukhich); 

ImGui::Checkbox("Naruto: Đe Doạ", &cuoi); 

ImGui::TextColored(ImColor(0, 255, 0), "Evogun");

ImGui::Checkbox("Scar Cá Mập Đen: Đe Doạ", &doa);

ImGui::Checkbox("M1887 Vũ Trụ: Dab", &dab); 

ImGui::Checkbox("MP40 Tia Chớp: Vỗ Tay", &votay); 

ImGui::Checkbox("M1014 Huyết Hoả: Huyền Thoại Tử Chiến", &httc);

ImGui::Checkbox("Groza Màu Mè: Cao Thủ Tử Chiến", &cttc);

            } if (selectedTab == 4) {
              ImGui::Separator();


                if (ImGui::Button("Fix Login Account"))
    {
        self.mtkView.hidden = YES;
        MenDeal = NO;
        timer(30) {
            self.mtkView.hidden = NO;
            MenDeal = YES;
        });
    }      
         if (ImGui::BeginCombo(ENCRYPT("Style"), selectedStyle.c_str())) {
            if (ImGui::Selectable(ENCRYPT("Light"))) {
ImGui::StyleColorsLight();
                selectedStyle = "Light";
            }
            if (ImGui::Selectable(ENCRYPT("Dark"))) {
ImGui::StyleColorsDark();
selectedStyle = "Dark";
            }
            if (ImGui::Selectable(ENCRYPT("Dark Mode"))) {
    SetDarkThemeColors();
selectedStyle = "Dark Mode";
            }
            if (ImGui::Selectable(ENCRYPT("Classic"))) {
ImGui::StyleColorsClassic();
selectedStyle = "Classic";
            }
            ImGui::EndCombo();
        }

    ImGui::TextColored(ImColor(0, 255, 0), "Camera Control: ");
ImGui::SliderFloat(ENCRYPT(" "), &camxa, 60.0f, 120.0f, "  Camera Distance[ %.0f ]");

ImGui::Checkbox(ENCRYPT("Livestream Mode"), &StreamerMode);

             }

            ImGui::PopStyleVar(2);

            ImGui::Spacing();
      
            ImGui::Spacing();

            ImGui::End();
}

        if (sen && !hasGhostBeenDrawn) {
            [self ghost];
        } else if (!sen) {
            [self removeGhost];
        }

DrawEsp();
IGGCODE();

    
            ImGui::Render();
            ImDrawData* draw_data = ImGui::GetDrawData();
            ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);

            [renderEncoder popDebugGroup];
            [renderEncoder endEncoding];

            [commandBuffer presentDrawable:view.currentDrawable];
            
        }
        [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

void DrawAimbotTab() {
    static int selectedAimWhen = AimWhen; // Biến lưu giá trị AimWhen đã chọn

    
    
    // Combo box cho AimWhen
    const char* aimWhenOptions[] = {"Aim To Kill", "Aim Fire", "Aim Scope"};
    ImGui::Combo("", &selectedAimWhen, aimWhenOptions, IM_ARRAYSIZE(aimWhenOptions));

ImGui::SliderInt("", &AimDis, 0.0f, 999.0f, "AIM Distance [ %.0f ]");

    // Cập nhật AimWhen từ selectedAimWhen
    AimWhen = selectedAimWhen;
}
void IGGCODE() {
    

   if (aim180) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 1057048494;
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            uint32_t search1 = 1054951342;
            engine.JRNearBySearch(0x100, &search1, JR_Search_Type_UInt);
            uint32_t search2 = 1053273620;
            engine.JRNearBySearch(0x100, &search2, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = -2000;
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (tawm) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine(mach_task_self());
            AddrRange range = {0x100000000, 0x160000000};
            uint64_t searchNumber = 4603687625386098688ULL;
            engine.JRScanMemory(range, &searchNumber, JR_Search_Type_ULong);
            std::vector<void*> results = engine.getAllResults();
            float newValueFloat = 0.01f;
            int32_t newValueInt = 0;
            for (void* addr : results) {
                uint64_t addr1 = reinterpret_cast<uint64_t>(addr);
                uint64_t dizhi0 = addr1 + 36;
                uint64_t dizhi1 = addr1 + 40;
                uint64_t dizhi2 = addr1 - 308;
                engine.JRWriteMemory(dizhi0, &newValueFloat, JR_Search_Type_Float);
                engine.JRWriteMemory(dizhi1, &newValueFloat, JR_Search_Type_Float);
                engine.JRWriteMemory(dizhi2, &newValueInt, JR_Search_Type_SInt);
            }
        });
    }

    if (Locktam) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x160000000};
            float search = 0.15;
            engine.JRScanMemory(range, &search, JR_Search_Type_Float);
            float search1 = 1.5;
            engine.JRNearBySearch(0x60, &search1, JR_Search_Type_Float);
            float search2 = 1.5;
            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
            std::vector<void*> results = engine.getAllResults();
            float modify = 9999;
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
            }
        });
    }

    if (aimawm) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint64_t search = 31101603021;
            engine.JRScanMemory(range, &search, JR_Search_Type_ULong);std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 2139095040;
            for (size_t i = 0; i < results.size(); i++) {
                uint64_t addr1 = reinterpret_cast<uint64_t>(results[i]);
                uint64_t dizhi0 = addr1 + 8;
                engine.JRWriteMemory(dizhi0, &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (chao) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909000001;  // mã hành động gốc
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909047015; // mã mod
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (aimscope) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x160000000};
            uint32_t search = 1075000115;
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            uint32_t search1 = 3;
            engine.JRNearBySearch(0x100, &search1, JR_Search_Type_UInt);
            uint32_t search2 = 1075000115;
            engine.JRScanMemory(range, &search2, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = -5;
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (hscu) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x160000000};
            uint32_t search = 2183231598;
            engine.JRScanMemory(range, &search, JR_Search_Type_Float);
            uint32_t search1 = 96688289;
            engine.JRNearBySearch(0x10, &search1, JR_Search_Type_Float);
            uint32_t search2 = 96688289;
            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 2018908708;
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
            }
        });
    }

    if (antenatay) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x160000000};
            float search = 3.2404066e-7F;
            engine.JRScanMemory(range, &search, JR_Search_Type_Float);
            float search1 = 1;engine.JRNearBySearch(0x20, &search1, JR_Search_Type_Float);
            float search2 = 1;
            engine.JRScanMemory(range, &search2, JR_Search_Type_Float);
            float search3 = -0.39830258489F;
            engine.JRScanMemory(range, &search3, JR_Search_Type_Float);
            float search4 = 1;
            engine.JRNearBySearch(0x20, &search4, JR_Search_Type_Float);
            float search5 = 1;
            engine.JRScanMemory(range, &search5, JR_Search_Type_Float);
            std::vector<void*> results = engine.getAllResults();
            float modify = 200;
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_Float);
            }
        });
    }

    
    if (votay) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909000004;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909040010; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }


    if (dame) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self()); 
        AddrRange range = (AddrRange){0x100000000,0x160000000}; 
        float search = 5.5; 
        engine.JRScanMemory(range, &search, JR_Search_Type_Float); 
        float search1 = 1; 
        engine.JRNearBySearch(0x20, &search1, JR_Search_Type_Float); 
        vector<void*>results = engine.getAllResults(); 
        float modify = 9999999; 
        for(int i =0;i<results.size();i++){ 
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_Float); 
            }
        });
    }


    if (igg) {
        static dispatch_once_t onceToken;
      dispatch_once(&onceToken, ^{
     JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
        AddrRange range = {0x100000000, 0x200000000};
        uint64_t search = 4397530849764387586;
        engine.JRScanMemory(range, &search, JR_Search_Type_ULong);   
        vector<void*>results = engine.getAllResults();
        uint64_t modify = 4397530849764387586;
        for(int i =0;i<results.size();i++){
        engine.JRWriteMemory((unsigned long long)(results[i]),&modify,
            JR_Search_Type_ULong);
        }
     });
}

    if (khieukhich) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909000003;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909047019; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (dab) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909000005;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909035007; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

if (doa) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909000018;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909000068; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

if (httc) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909034012;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909039011; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

if (cttc) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909034013;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 909041005; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (cuoi) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 909000002;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 912047001; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (m4a1) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 907104540;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 907193107; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }

    if (ump) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = {0x100000000, 0x200000000};
            uint32_t search = 907101623;  
            engine.JRScanMemory(range, &search, JR_Search_Type_UInt);
            std::vector<void*> results = engine.getAllResults();
            uint32_t modify = 907193007; 
            for (size_t i = 0; i < results.size(); i++) {
                engine.JRWriteMemory((unsigned long long)(results[i]), &modify, JR_Search_Type_UInt);
            }
        });
    }
}


@end